#include <stdio.h>
#include "LPC11xx.h"
#include <rt_misc.h>
#include <stdbool.h>
#include <core_cm0.h>
#include "i2c.h"

extern void SER_init (void);

void configureGPIO()
{
	LPC_SYSCON->CLKOUTCLKSEL |= (3);
	//LPC_IOCON->PIO0_1 &= ~0x3F; // Select clkout function for P0.1
	LPC_IOCON->PIO0_1 |= 0x01;
	
	LPC_SYSCON->CLKOUTUEN |= 1;
	LPC_SYSCON->CLKOUTUEN |= 0;
	LPC_SYSCON->CLKOUTUEN |= 1;
	
	while ( !(LPC_SYSCON->CLKOUTUEN & 0x01) ); // Wait until updated
	LPC_SYSCON->CLKOUTDIV |= 1;
	
	//enable clocks to GPIO block
	LPC_SYSCON->SYSAHBCLKCTRL |= (1UL <<  6); // GPIO enable
	LPC_SYSCON->SYSAHBCLKCTRL |= (1UL <<  16); // IOCON enable

	//set port 0_7 to output (high current drain in LPC1114)
    LPC_GPIO0->DIR |= (1<<7);
}

void ledOn(void)
{
	LPC_GPIO0->DATA &= ~(1<<7);
}

void ledOff(void)
{						 
	LPC_GPIO0->DATA |= (1<<7);
}

int8_t data_convert(uint8_t data)
{
	int8_t ret = (3 << 6);
	if((data >> 5) == 1)
	{
		ret = ret + data;
		return ret;
	}
	else
	{
		return data;
	}
}

int main()
{
	uint8_t data;
	int8_t gs;
	SER_init();
	configureGPIO();
	configure_i2c();
	printf("START HERE \n\r");
	
	ledOn();
	
	write_address(0x4C, 0);
	
	write_byte(0x07);
	write_byte(0x01);
	LPC_I2C->CONSET |= 0x10;
	LPC_I2C->CONCLR = 0x08;
	
	printf("MODE SET \n\r");
	
		for(int i = 0; i < 0xFFFFF; i++)
		{}
		
		write_address(0x4C, 0);
		write_byte(0x04);
		LPC_I2C->CONSET |= 0x10;
		LPC_I2C->CONCLR = 0x08;
			
		write_address(0x4C, 1);
		for(int i = 0; i < 0xFFFFF; i++)
		{}
		//LPC_I2C->CONCLR = 0x20; //clr Start and SI bits
		data = read_byte();
		LPC_I2C->CONSET |= 0x10;
		LPC_I2C->CONCLR = 0x08;
			
		printf("0x%04x \n\r", data);
	
	while(1)
	{
		for(int i = 0; i < 0xFFFFF; i++)
		{}
		
		write_address(0x4C, 0);
		write_byte(0x02);
		LPC_I2C->CONSET |= 0x10;
		LPC_I2C->CONCLR = 0x08;
			
		write_address(0x4C, 1);
			for(int i = 0; i < 0xFFFFF; i++)
		{}
		//LPC_I2C->CONCLR = 0x20; //clr Start and SI bits
		data = read_byte();
		LPC_I2C->CONSET |= 0x10;
		LPC_I2C->CONCLR = 0x08;
		
		gs = data_convert(data);
		
		printf("%d \n\r", gs);
		
	}

}