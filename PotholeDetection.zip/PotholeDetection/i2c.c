#include "I2C.h"

void configure_i2c(void)
{
	LPC_IOCON->PIO0_4 |= 1UL;
	LPC_IOCON->PIO0_5 |= 1UL;
	
	LPC_SYSCON->SYSAHBCLKCTRL |= (1UL<<5);
	
	LPC_SYSCON->PRESETCTRL &= ~(1UL<<1);
	LPC_SYSCON->PRESETCTRL |= (1UL<<1); 
	
	LPC_I2C->CONSET |= (1UL << 6); // Set to Master
	
	LPC_I2C->SCLH = 0x001E; // Set register to 30 for 12MHz Clock for Fast Mode
	LPC_I2C->SCLL = 0x0000;
	
}

void write_address(uint8_t addr, uint8_t rw)
{
	LPC_I2C->CONSET |= (1UL << 5);
	
	while(LPC_I2C->STAT == 0xF8)
	{
		//printf("waiting on F8 \n\r");
	}
	uint32_t status = LPC_I2C->STAT;
	
	if(status == 0x08)
	{
		//printf("Success Start \n\r");
		LPC_I2C->DAT = (addr << 1) + (rw); 
		LPC_I2C->CONCLR = 0x28; //clr Start and SI bits
	}
	else
	{
		printf("ADDR ERR: 0x%04x \n\r", status);
		return;
	}
	
	while(LPC_I2C->STAT == 0xF8)
	{}
	status = LPC_I2C->STAT;
	
	if(status == 0x18) //write
	{
		printf("Success ADDR Write \n\r");
		return;
	}
	else if(status == 0x40) //read
	{
		printf("Success ADDR Read \n\r");
		return;
	}
	else
	{
		printf("ADDR ERR: 0x%04x \n\r", status);
		return;
	}
}

void write_byte(uint8_t byte)
{
	LPC_I2C->DAT = byte; // Load data into data register
	LPC_I2C->CONCLR = 0x08;
	
	while(LPC_I2C->STAT == 0xF8)
	{}
	uint32_t status = LPC_I2C->STAT;
	
	if(status == 0x28) // Byte sent correctly
	{
		printf("Success Write \n\r");
		return;
	}
	else
	{
		printf("WRITE ERR: 0x%04x \n\r", status);
		return;
	}
}

uint8_t read_byte(void)
{
	uint8_t byte = LPC_I2C->DAT;
	LPC_I2C->CONCLR = 0x08;
	
	while(LPC_I2C->STAT == 0xF8)
	{}
	uint32_t status = LPC_I2C->STAT;
		
	if(status == 0x58) // Byte sent correctly NACK Sent
	{
		printf("Success Read \n\r");
		printf("DATA: %d \n\r", byte);
		return byte;
	}
	else
	{
		printf("READ ERR: 0x%04x \n\r", status);
		printf("ERR DATA: %d \n\r", byte);
		return 0;
	}
}

void I2C_write(uint8_t address, uint8_t byte)
{
	write_address(address, 0x00);
	write_byte(byte);
	
	LPC_I2C->CONSET |= 0x10;
	LPC_I2C->CONCLR = 0x08;
}

uint8_t I2C_read(uint8_t address)
{
	uint8_t ret;
	write_address(address, 0x01);
	ret = read_byte();
	
	LPC_I2C->CONSET |= 0x10;
	LPC_I2C->CONCLR = 0x08;
	return ret;
}
