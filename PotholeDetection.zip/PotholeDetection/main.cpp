#include <stdio.h>
#include "LPC11xx.h"
#include <rt_misc.h>
#include <stdbool.h>
#include <core_cm0.h>
#include "Serial.c"
#include "i2c.h"


//extern void SER_init (void);
extern void configureGPIO (void);
extern void write_address (uint8_t addr, uint8_t rw);

void configureGPIO()
{
	LPC_SYSCON->CLKOUTCLKSEL |= (3);
	//LPC_IOCON->PIO0_1 &= ~0x3F; // Select clkout function for P0.1
	LPC_IOCON->PIO0_1 |= 0x01;
	
	LPC_SYSCON->CLKOUTUEN |= 1;
	LPC_SYSCON->CLKOUTUEN |= 0;
	LPC_SYSCON->CLKOUTUEN |= 1;
	
	while ( !(LPC_SYSCON->CLKOUTUEN & 0x01) ); // Wait until updated
	LPC_SYSCON->CLKOUTDIV |= 1;
	
	//enable clocks to GPIO block
	LPC_SYSCON->SYSAHBCLKCTRL |= (1UL <<  6); // GPIO enable
	LPC_SYSCON->SYSAHBCLKCTRL |= (1UL <<  16); // IOCON enable

	//set port 0_7 to output (high current drain in LPC1114)
    LPC_GPIO0->DIR |= (1<<7);
}

void ledOn(void)
{
	LPC_GPIO0->DATA &= ~(1<<7);
}

void ledOff(void)
{						 
	LPC_GPIO0->DATA |= (1<<7);
}

int main()
{
	SER_init();
	configureGPIO();
	configure_i2c();
	printf("Hello");
	
	ledOn();
	
	write_address(0x4C, 1);

}
